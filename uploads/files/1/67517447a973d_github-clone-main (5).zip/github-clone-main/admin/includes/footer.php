    <!-- Footer -->
    <footer class="py-3 bg-dark text-white text-center mt-auto">
        <p class="mb-0">Admin Dashboard © 2024 | All Rights Reserved</p>
    </footer>

    <!-- Bootstrap JS (for navbar toggling) -->
    <script src="../vendor/twbs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>