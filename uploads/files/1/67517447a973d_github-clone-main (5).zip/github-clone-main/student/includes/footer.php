 <!-- Footer -->
 <footer class="footer">
     <p>&copy; <?php echo date("Y"); ?> ZDSPGC. All Rights Reserved. <a href="#">Privacy Policy</a></p>
 </footer>

 <!-- Bootstrap JS -->
 <!-- Bootstrap JS (for navbar toggling) -->
 <script src="../vendor/twbs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
 <!-- Bootstrap 5 JS and dependencies -->
 <script src="../node_modules/@popperjs/core/dist/umd/popper.min.js"></script>
 <script src="../vendor/twbs/bootstrap/dist/js/bootstrap.min.js"></script>

 </body>

 </html>