    <!-- Footer -->
    <footer class="py-3 bg-dark text-white text-center mt-auto">
        <p class="mb-0">Admin Dashboard © 2024 | All Rights Reserved</p>
    </footer>

    <!-- Bootstrap JS (for navbar toggling) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>